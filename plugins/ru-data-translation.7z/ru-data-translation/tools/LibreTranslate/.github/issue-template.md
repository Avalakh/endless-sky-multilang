---
name: Issue Template
about: Default issue template
title: ''
labels: ''
assignees: ''

---

****************************************
Please open an issue only to report faults, bugs or feature requests. For questions and installation problems please open a topic on https://community.libretranslate.com
****************************************
